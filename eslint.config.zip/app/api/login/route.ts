import { NextResponse } from "next/server";

export async function POST(req: Request) {
  const body = await req.json();

  const resBack = await fetch("http://localhost:4000/login", {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify(body),
    credentials: "include"
  });

  const data = await resBack.json();

  const response = NextResponse.json(data, { status: resBack.status });

  const token = resBack.headers.get("set-cookie");

  if (token) {
    response.headers.set("set-cookie", token);
  }

  return response;
}
