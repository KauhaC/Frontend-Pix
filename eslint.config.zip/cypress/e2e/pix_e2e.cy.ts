describe("Fluxo PIX completo - Login → Transferência → Extrato", () => {
  const FRONT = "http://localhost:3000";
  const API = "http://localhost:4000";

  const remetenteCpf = "11122233344";
  const senha = "123456";
  const chaveDestino = "destino@pix.com";

  beforeEach(() => {
    cy.clearLocalStorage();
  });

  it("Realiza login, envia PIX com modal e verifica no extrato", () => {

    // ============================
    // 1. LOGIN
    // ============================
    cy.visit(`${FRONT}/login`);

    cy.get("input[placeholder='Digite seu CPF ou CNPJ']").type(remetenteCpf);
    cy.get("input[placeholder='Digite sua senha']").type(senha);

    cy.intercept("POST", `${API}/login`).as("login");

    cy.get("button[type='submit']").click();

    cy.wait("@login").its("response.statusCode").should("eq", 200);

    cy.url().should("include", "/dashboard");

    // ============================
    // 2. IR PARA TRANSFERÊNCIA
    // ============================
    cy.contains("Transferência").click();

    cy.url().should("include", "/transferencia");

    // Selecionar tipo EMAIL
    cy.get("select").select("E-mail");

    // Inserir chave destino
    cy.get("input[placeholder='email@exemplo.com']").type(chaveDestino);

    // Aguardar verificação da chave PIX (debounce de 500ms)
    cy.wait(600);

    cy.contains("Enviar para:").should("exist");
    cy.contains("Destinatario Teste").should("exist");

    // Inserir valor
    cy.get('input[type="number"]').type("10");

    // Inserir descrição
    cy.get('input[placeholder="Opcional"]').type("Teste Cypress");

    // Abrir modal
    cy.get(".btn-confirmar").click();

    // Confirmar modal
    cy.contains("Confirmar").click();

    cy.intercept("POST", `${API}/transacoes/enviar`).as("enviarPix");

    cy.wait("@enviarPix").its("response.statusCode").should("eq", 201);

    cy.contains("Transferência realizada com sucesso!").should("exist");

    // ============================
    // 3. IR PARA O EXTRATO
    // ============================
    cy.contains("Extrato").click();

    cy.url().should("include", "/extrato");

    cy.intercept("GET", `${API}/transacoes*`).as("extratoGet");

    cy.wait("@extratoGet").its("response.statusCode").should("eq", 200);

    // ============================
    // 4. VERIFICAR ÚLTIMA TRANSAÇÃO
    // ============================
    cy.contains("SAIDA").should("exist");
    cy.contains("R$ 10,00").should("exist");
    cy.contains("Teste Cypress").should("exist");

    // ============================
    // 5. VERIFICAR SELETORES DE PAGINAÇÃO
    // ============================
    cy.get(".btn-page").contains("Próxima →").should("exist");
    cy.get(".btn-page").contains("← Anterior").should("exist");
  });
});
